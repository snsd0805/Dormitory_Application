<?php
interface product
{
    function getProperties();
}
?>